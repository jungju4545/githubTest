```sql
create user 'helloflea'@'%' identified by 'helloflea';
GRANT ALL PRIVILEGES ON *.* TO 'helloflea'@'%';
create database helloflea;
```

yml에 포트 수정!!