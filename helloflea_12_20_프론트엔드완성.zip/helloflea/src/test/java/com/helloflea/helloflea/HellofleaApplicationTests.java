package com.helloflea.helloflea;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HellofleaApplicationTests {

	@Test
	void contextLoads() {
	}

}
